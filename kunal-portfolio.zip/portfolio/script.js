/* script.js — site behaviour. Your content lives in config.js, not here. */
(function () {
  "use strict";
  const C = window.SITE_CONFIG;
  const $ = (s) => document.querySelector(s);
  const el = (tag, attrs = {}, text) => { const e = document.createElement(tag); Object.entries(attrs).forEach(([k, v]) => e.setAttribute(k, v)); if (text != null) e.textContent = text; return e; };

  /* Theme colors from config */
  const r = document.documentElement.style;
  r.setProperty("--bg", C.theme.bg); r.setProperty("--navy", C.theme.navy);
  r.setProperty("--blue", C.theme.blue); r.setProperty("--purple", C.theme.purple);

  /* Toast */
  let tt;
  function toast(msg) { const t = $("#toast"); t.textContent = msg; t.classList.add("show"); clearTimeout(tt); tt = setTimeout(() => t.classList.remove("show"), 3200); }

  /* Fill content */
  $("#logoText").textContent = C.initials;
  $("#heroName").textContent = C.name;
  $("#headline").textContent = C.headline;
  $("#education").textContent = C.education;
  $("#year").textContent = new Date().getFullYear();
  $("#profileFallback").textContent = C.initials;
  const img = $("#profileImg");
  img.onerror = () => { img.hidden = true; $("#profileFallback").hidden = false; };
  img.src = C.profileImage;

  C.about.forEach((p) => $("#aboutText").appendChild(el("p", {}, p)));
  C.interests.forEach((i) => $("#interests").appendChild(el("span", { class: "chip" }, i)));

  C.skills.forEach((s, i) => {
    const d = el("div", { class: "glass skill reveal" }); d.style.transitionDelay = i * 40 + "ms";
    d.appendChild(el("span", { class: "ic", "aria-hidden": "true" }, s.icon)); d.appendChild(el("strong", {}, s.name));
    $("#skillGrid").appendChild(d);
  });

  C.projects.forEach((p) => {
    const card = el("article", { class: "glass project reveal" });
    card.appendChild(el("h3", {}, p.title)); card.appendChild(el("p", {}, p.description));
    const chips = el("div", { class: "chips" }); p.tech.forEach((t) => chips.appendChild(el("span", { class: "chip" }, t))); card.appendChild(chips);
    const b = el("div", { class: "btns" });
    b.appendChild(el("a", { class: "btn btn-glow sm", href: p.github, target: "_blank", rel: "noopener" }, "View Source Code"));
    b.appendChild(el("a", { class: "btn btn-ghost sm", href: p.github, target: "_blank", rel: "noopener" }, "GitHub"));
    card.appendChild(b); $("#projectGrid").appendChild(card);
    const a = el("a", { href: p.github, target: "_blank", rel: "noopener" }, "→ " + p.title); $("#repoLinks").appendChild(a);
  });

  const I = C.internship;
  $("#internOrg").textContent = "@ " + I.organization; $("#internRole").textContent = I.role; $("#internDesc").textContent = I.description;
  if (I.verificationUrl) { const l = $("#internLink"); l.href = I.verificationUrl; l.hidden = false; }
  if (I.certificateImage) { $("#certBox").appendChild(el("img", { src: I.certificateImage, alt: "Internship certificate" })); }
  else { $("#certBox").textContent = "Certificate image will appear here — add it in config.js (internship.certificateImage)."; }

  $("#ghUser").textContent = "@" + C.githubUsername;
  $("#ghBtn").href = C.github; $("#liBtn").href = C.linkedin;
  const sl = $("#socialLinks");
  sl.appendChild(el("a", { class: "btn btn-ghost sm", href: C.github, target: "_blank", rel: "noopener" }, "GitHub"));
  sl.appendChild(el("a", { class: "btn btn-ghost sm", href: C.linkedin, target: "_blank", rel: "noopener" }, "LinkedIn"));
  if (C.email) sl.appendChild(el("a", { class: "btn btn-ghost sm", href: "mailto:" + C.email }, "Email"));

  /* Resume */
  const rb = $("#resumeBtn");
  if (C.resumeUrl) { rb.href = C.resumeUrl; rb.target = "_blank"; rb.rel = "noopener"; }
  else rb.addEventListener("click", (e) => { e.preventDefault(); toast("Resume coming soon."); });

  /* Rotating roles */
  let ri = 0, ci = 0, del = false;
  (function type() {
    const word = C.roles[ri]; $("#roleText").textContent = word.slice(0, ci);
    if (!del && ci < word.length) ci++; else if (del && ci > 0) ci--; else if (!del) { del = true; return setTimeout(type, 1500); } else { del = false; ri = (ri + 1) % C.roles.length; }
    setTimeout(type, del ? 40 : 80);
  })();

  /* Navbar + mobile menu */
  const nav = $("#nav"), burger = $("#burger"), links = $("#navLinks");
  addEventListener("scroll", () => nav.classList.toggle("scrolled", scrollY > 20), { passive: true });
  burger.addEventListener("click", () => { const o = links.classList.toggle("open"); burger.classList.toggle("open", o); burger.setAttribute("aria-expanded", o); });
  links.querySelectorAll("a").forEach((a) => a.addEventListener("click", () => { links.classList.remove("open"); burger.classList.remove("open"); burger.setAttribute("aria-expanded", "false"); }));
  $("#toTop").addEventListener("click", () => scrollTo({ top: 0, behavior: "smooth" }));

  /* Reveal on scroll */
  const io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } }), { threshold: 0.12 });
  document.querySelectorAll(".reveal").forEach((n) => io.observe(n));

  /* Contact form — validates; does NOT pretend to send (no backend yet).
     To make it real, use a service like Formspree: set the form action and remove the preventDefault. */
  $("#contactForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const f = e.target, note = $("#formNote");
    const name = f.name.value.trim(), email = f.email.value.trim(), msg = f.message.value.trim();
    if (!name || !msg || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { note.textContent = "Please fill in your name, a valid email and a message."; return; }
    note.textContent = "Messaging isn't connected yet — please reach me on LinkedIn for now. Your message was not sent.";
  });

  /* AI assistant — predefined answers now; real AI later via YOUR backend (C.aiEndpoint). */
  const chat = $("#chat"), body = $("#chatBody");
  function addMsg(text, who) { const m = el("div", { class: "msg " + who }, text); body.appendChild(m); body.scrollTop = body.scrollHeight; return m; }
  function localAnswer(q) {
    const s = q.toLowerCase();
    const hit = C.assistantQA.find((x) => x.keys.some((k) => s.includes(k)));
    return hit ? hit.answer : "I can answer questions about Kunal's profile, skills, projects, internship and contact info. Try one of the suggestions!";
  }
  async function getAnswer(q) {
    if (C.aiEndpoint) {
      try { const res = await fetch(C.aiEndpoint, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ question: q }) }); if (res.ok) { const d = await res.json(); if (d.answer) return d.answer; } } catch (_) {}
    }
    return localAnswer(q);
  }
  async function ask(q) {
    q = q.trim().slice(0, 300); if (!q) return;
    addMsg(q, "user");
    const typing = addMsg("", "bot"); typing.innerHTML = '<span class="dots"><span></span><span></span><span></span></span>';
    const [ans] = await Promise.all([getAnswer(q), new Promise((r) => setTimeout(r, 700))]);
    typing.textContent = ""; let i = 0;
    (function t() { typing.textContent = ans.slice(0, ++i); body.scrollTop = body.scrollHeight; if (i < ans.length) setTimeout(t, 12); })();
  }
  C.assistantSuggestions.forEach((s) => { const b = el("button", { type: "button" }, s); b.onclick = () => ask(s); $("#chatSuggest").appendChild(b); });
  $("#chatToggle").onclick = () => { chat.hidden = !chat.hidden; if (!chat.hidden && !body.children.length) addMsg("Hi! I'm Kunal's assistant. Ask me about his skills, projects or internship.", "bot"); if (!chat.hidden) $("#chatInput").focus(); };
  $("#chatClose").onclick = () => (chat.hidden = true);
  $("#chatForm").addEventListener("submit", (e) => { e.preventDefault(); const i = $("#chatInput"); ask(i.value); i.value = ""; });

  /* Particles (light, capped for performance) */
  const cv = $("#particles"), ctx = cv.getContext("2d"); let W, H, P = [];
  function size() { W = cv.width = innerWidth; H = cv.height = innerHeight; const n = Math.min(70, Math.floor(W / 20)); P = Array.from({ length: n }, () => ({ x: Math.random() * W, y: Math.random() * H, vx: (Math.random() - .5) * .3, vy: (Math.random() - .5) * .3, r: Math.random() * 1.6 + .4 })); }
  size(); addEventListener("resize", size);
  if (!matchMedia("(prefers-reduced-motion: reduce)").matches) (function draw() {
    ctx.clearRect(0, 0, W, H);
    for (let i = 0; i < P.length; i++) { const p = P[i]; p.x = (p.x + p.vx + W) % W; p.y = (p.y + p.vy + H) % H;
      ctx.fillStyle = i % 2 ? C.theme.blue : C.theme.purple; ctx.globalAlpha = .7; ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 7); ctx.fill();
      for (let j = i + 1; j < P.length; j++) { const q = P[j], d = Math.hypot(p.x - q.x, p.y - q.y); if (d < 110) { ctx.globalAlpha = (1 - d / 110) * .15; ctx.strokeStyle = C.theme.blue; ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y); ctx.stroke(); } } }
    requestAnimationFrame(draw);
  })();
})();
