# Kunal Bobade — Portfolio 2.0

```
portfolio/
├── index.html   ← page structure
├── style.css    ← design
├── script.js    ← behaviour
├── config.js    ← ALL your info (edit this)
├── images/      ← profile.jpg, certificate.jpg
└── resume/      ← your resume PDF
```

Run locally: open the folder in VS Code → install "Live Server" → right-click index.html → Open with Live Server.
Deploy: push to a GitHub repo → Settings → Pages → Branch: main / root → Save.
