/* ==========================================================================
   config.js — EDIT YOUR INFORMATION HERE
   Everything shown on the website (name, links, skills, projects, colors,
   chatbot answers) comes from this one file. Change values, save, refresh.
   ========================================================================== */
window.SITE_CONFIG = {
  /* ---------- Basic profile ---------- */
  name: "Kunal Bobade",
  initials: "KB",
  headline: "B.Tech Data Science student building practical, data-driven solutions with Python and Machine Learning.",
  roles: ["Data Science Student", "Machine Learning Enthusiast", "Python Developer", "Future AI Engineer"],
  education: "B.Tech in Data Science — Third Year",

  /* Put your photo at images/profile.jpg (relative path). If it is missing, initials are shown. */
  profileImage: "images/profile.jpg",

  /* Put your resume PDF in the resume/ folder and set the path, e.g. "resume/Kunal_Bobade_Resume.pdf".
     Leave "" until you add it — the button will tell visitors it's coming soon. */
  resumeUrl: "",

  /* ---------- Social links ---------- */
  github: "https://github.com/kunalbobade409-tech",
  githubUsername: "kunalbobade409-tech",
  linkedin: "https://www.linkedin.com/in/kunal-bobade-296738386/",
  email: "", // e.g. "you@example.com" — leave "" to hide the email link

  /* ---------- About ---------- */
  about: [
    "I'm a third-year B.Tech Data Science student who enjoys turning raw data into clear insights and useful tools.",
    "My interests include Python, data analysis, Machine Learning and Artificial Intelligence. I learn best by building real-world projects — from optimisation algorithms to exploratory data analysis and ML models.",
    "I'm currently growing my skills through hands-on projects and my Machine Learning & Data Science internship at Datheon."
  ],
  interests: ["Data Science", "Python", "Machine Learning", "Artificial Intelligence", "Real-world Projects"],

  /* ---------- Skills (no fake percentages) ---------- */
  skills: [
    { name: "Python", icon: "🐍" },
    { name: "Pandas", icon: "🐼" },
    { name: "NumPy", icon: "🔢" },
    { name: "Matplotlib", icon: "📈" },
    { name: "Machine Learning", icon: "🤖" },
    { name: "Data Analysis", icon: "🔍" },
    { name: "SQL", icon: "🗄️" },
    { name: "GitHub", icon: "🐙" },
    { name: "HTML", icon: "🧱" },
    { name: "CSS", icon: "🎨" },
    { name: "JavaScript", icon: "⚡" }
  ],

  /* ---------- Projects ----------
     To add a project, copy one { ... } block, paste it below, and edit it.
     "github" should be the repository URL. */
  projects: [
    {
      title: "Smart Budget Allocation System",
      description: "Allocates a limited budget across options to maximise total value using the 0/1 Knapsack Dynamic Programming algorithm.",
      tech: ["Python", "Dynamic Programming", "0/1 Knapsack"],
      github: "https://github.com/kunalbobade409-tech"
    },
    {
      title: "Data Analysis Projects",
      description: "Exploratory data analysis — cleaning, transforming and visualising datasets to uncover patterns and insights.",
      tech: ["Python", "Pandas", "Matplotlib"],
      github: "https://github.com/kunalbobade409-tech"
    },
    {
      title: "ML & Data Science Internship Projects",
      description: "Machine Learning and Data Science work completed during my internship at Datheon.",
      tech: ["Python", "Machine Learning", "Data Science"],
      github: "https://github.com/kunalbobade409-tech"
    }
  ],

  /* ---------- Internship ----------
     certificateImage: e.g. "images/certificate.jpg" (leave "" to show a placeholder)
     verificationUrl: certificate verification or project link (leave "" to hide) */
  internship: {
    organization: "Datheon",
    role: "Machine Learning & Data Science Intern",
    description: "Hands-on internship focused on Machine Learning and Data Science — working with data, building models and applying Python tools to practical problems.",
    certificateImage: "",
    verificationUrl: ""
  },

  /* ---------- Theme colors ---------- */
  theme: {
    bg: "#05060f",
    navy: "#0a1030",
    blue: "#3ab7ff",
    purple: "#9b5cff"
  },

  /* ---------- AI assistant ----------
     Predefined answers (keyword -> answer). To connect a real AI later, set
     aiEndpoint to YOUR OWN secure backend URL (never put API keys here). */
  aiEndpoint: "",
  assistantQA: [
    { keys: ["who", "about", "yourself", "kunal"], answer: "Kunal Bobade is a third-year B.Tech Data Science student interested in Python, Machine Learning and AI, who loves building real-world projects." },
    { keys: ["skill", "know", "tech", "stack"], answer: "Kunal works with Python, Pandas, NumPy, Matplotlib, Machine Learning, Data Analysis, SQL, GitHub, HTML, CSS and JavaScript." },
    { keys: ["project", "built", "work"], answer: "Projects include a Smart Budget Allocation System (0/1 Knapsack DP), Data Analysis projects with Pandas & Matplotlib, and ML/Data Science internship projects. See the Projects section!" },
    { keys: ["intern", "datheon", "experience"], answer: "Kunal completed a Machine Learning & Data Science internship at Datheon." },
    { keys: ["education", "study", "college", "degree"], answer: "Kunal is pursuing a B.Tech in Data Science and is currently in his third year." },
    { keys: ["contact", "reach", "linkedin", "email", "hire"], answer: "You can reach Kunal via LinkedIn or the contact form below. Links are in the Contact section." },
    { keys: ["github", "code", "repo"], answer: "Kunal's code lives on GitHub: github.com/kunalbobade409-tech" }
  ],
  assistantSuggestions: ["Who is Kunal?", "What are his skills?", "Show projects", "Internship?"]
};
